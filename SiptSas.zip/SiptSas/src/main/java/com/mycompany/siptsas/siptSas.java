
package com.mycompany.siptsas;


public class siptSas {
    public static void main(String[] args){

System.out.println("Por favor introduzca la operacion que desea realizar");

Menu menu = new Menu();

    Menu.menu;

}
}
