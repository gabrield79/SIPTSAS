
package com.mycompany.siptsas;

import java.util.Scanner;

public class Menu {
int selection;
String estacion ;

private Scanner input = new Scanner(System.in);

public void menu(){
System.out.println("-- Bienvenido "+ "por favor seleccione su opcion--");
System.out.println( " Nuestro menu: \n "+"1)"
+ "Digite la ruta del bus sobre la que desea conocer laas paradas \n" +
      "2) Consultar rutas que funcionan en feriados"
+" extendido \n"
);
 
             int selection=input.nextInt();
             input.nextLine();
switch (selection){
             case 1:
             consultarParadasdeRuta();
             break;
             case 2:
             consultarRutasenFeriados();
             break;
             default:
             System.out.println("Invalid selection.");
            break;
}
       


}

void consultarParadasdeRuta(){
System.out.println("Por favor introduzca la ruta del bus que desea conocer las paradas");
String rutadelBus="";
Scanner entradaEscaner = new Scanner (System.in);
rutadelBus=entradaEscaner.nextLine();
System.out.println("La ruta que usted ha ingresado es:\""+ rutadelBus);
paradas paradasdeRutas = new paradas();
estacion=paradasdeRutas.estaciondeParada(rutadelBus);
System.out.println("su estacion es: "+ estacion);
}

void consultarRutasenFeriados() {
System.out.println("Las rutas con horario extendido son: P49 y K905");
}

}

