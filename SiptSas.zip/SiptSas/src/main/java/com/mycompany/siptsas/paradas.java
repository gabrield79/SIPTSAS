package com.mycompany.siptsas;

public class paradas {
    
 String paradasdeRutas;
 
 String estaciondeParada(String rutadelBus)
    {
     if("G43".equals(rutadelBus)){
         paradasdeRutas="Alqueria,Venecia,La Despensa y San Mateo";
       }  
     else{
         System.out.println("No existe esta ruta");
     }
     
     return paradasdeRutas;
         
    }
    
}
